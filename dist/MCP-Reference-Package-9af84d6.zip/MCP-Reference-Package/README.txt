MCP Reference Package (version 9af84d6)

Reference material only. Read "0 - DISCLAIMER (read first).pdf" before anything else.
Nothing here may be adopted into a work environment without full review and vetting.

Contents
  0 - DISCLAIMER (read first).pdf   Terms: reference only, review before use, no warranty
  1 - MCP Guide.pdf                 How MCP works and how to build a server, step by step
  2 - MCP Publish.pdf               How to host it: container, configuration, pipeline, gateway
  3 - MCP Security.pdf              Security rules, the five test cases, evidence and limits
  code - tiny-tank-mcp/             The reference server, tests and test tools (Python)

Quick start for the code (Python 3.12+):
  cd "code - tiny-tank-mcp"
  python -m venv .venv
  .venv\Scripts\activate          (Linux/macOS: . .venv/bin/activate)
  pip install -r requirements.txt
  python -m pytest -v             expected: 79 passed
